/*
 * This is the app-level build.gradle.kts file (app/build.gradle.kts)
 * This file includes all necessary dependencies for Retrofit, OkHttp, and Gson.
 */

// PLUGINS block is required at the top
plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.android)
    // id("org.jetbrains.kotlin.plugin.compose") // 👈 REMOVED this plugin
}

android {
    namespace = "com.example.pfa_1" // Matches your project structure
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.pfa_1"

        // Set to 26 to support adaptive icons and modern features
        minSdk = 26

        targetSdk = 34
        versionCode = 1
        versionName = "1.0"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8

    }
    kotlinOptions {
        jvmTarget = "1.8"
    }
    // Enable View Binding (this is good practice)
    buildFeatures {
        viewBinding = true
        // compose = true // 👈 REMOVED this feature
    }
    /* 👈 REMOVED this entire block
    composeOptions {
        kotlinCompilerExtensionVersion = "1.5.14"
    }
    */
    packaging {
        resources {
            excludes += "/META-INF/{AL2.0,LGPL2.1}"
        }
    }
}

dependencies {
    // Existing dependencies
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.6.1")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")

    // This dependency is needed for registerForActivityResult
    implementation("androidx.activity:activity-ktx:1.9.0")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test.ext:junit:1.1.5")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.5.1")

    // --- LIBRARIES FOR NETWORKING AND IMAGE HANDLING ---

    // Retrofit for networking (making API calls)
    implementation("com.squareup.retrofit2:retrofit:2.9.0")

    // Gson converter for Retrofit (to convert JSON to Kotlin objects)
    implementation("com.squareup.retrofit2:converter-gson:2.9.0")

    // OkHttp (the underlying HTTP client for Retrofit)
    implementation("com.squareup.okhttp3:okhttp:4.12.0")

    // OkHttp Logging Interceptor (very useful for debugging API calls)
    implementation("com.squareup.okhttp3:logging-interceptor:4.12.0")

    // --- END OF NEW LIBRARIES ---
}

