package com.example.pfa_1

import com.google.gson.annotations.SerializedName

data class VerifyResponse(
    @SerializedName("status") val status: String?,
    @SerializedName("plate_number") val plateNumber: String?,
    @SerializedName("details") val details: Details?
)

data class Details(
    @SerializedName("owner") val owner: String?,
    @SerializedName("vehicle") val vehicle: String?,
    @SerializedName("notes") val notes: String?,
    @SerializedName("reference_image") val referenceImage: String?
)
