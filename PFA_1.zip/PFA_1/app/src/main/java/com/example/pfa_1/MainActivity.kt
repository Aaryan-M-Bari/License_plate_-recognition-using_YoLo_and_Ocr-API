package com.example.pfa_1 // Matches your project structure

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.util.Log
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
// We don't need these here anymore, they are in VerifyResponse.kt
// import com.google.gson.annotations.SerializedName
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
// --- FIX 2 (Import) ---
// Import 'asRequestBody' instead of 'toRequestBody'
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import retrofit2.http.Multipart
import retrofit2.http.POST
import retrofit2.http.Part
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

// =================================================================================
// !!! IMPORTANT - UPDATE THIS URL !!!
// =================================================================================
// Copy the 'https://' URL from your ngrok terminal and paste it here.
// It MUST end with a '/'
const val BASE_URL = "https://luxuriant-lorriane-undebited.ngrok-free.dev"
// Example: "https://luxuriant-lorriane-undebited.ngrok-free.dev/"
// =================================================================================


// --- Retrofit Interface for your API ---
interface ApiService {
    @Multipart
    @POST("verify-plate/") // Path is relative to BASE_URL
    fun verifyPlate(
        @Part file: MultipartBody.Part
    ): Call<VerifyResponse>
}

// --- MainActivity ---
class MainActivity : AppCompatActivity() {

    // --- View Variables ---
    private lateinit var imageView: ImageView
    private lateinit var btnCaptureImage: Button
    private lateinit var btnUploadImage: Button
    private lateinit var tvResult: TextView

    // --- State Variables ---
    private var currentPhotoUri: Uri? = null // Uri for the captured photo

    // --- Activity Result Launchers ---

    // 1. For launching the camera
    private val takePictureLauncher = registerForActivityResult(ActivityResultContracts.TakePicture()) { success: Boolean ->
        if (success) {
            currentPhotoUri?.let { uri ->
                imageView.setImageURI(uri) // Show the captured image
                btnUploadImage.isEnabled = true // Enable the verify button
                tvResult.text = "Image captured successfully. Ready to verify."
            }
        } else {
            Toast.makeText(this, "Image capture was cancelled or failed.", Toast.LENGTH_SHORT).show()
            tvResult.text = "Image capture failed."
            currentPhotoUri = null // Clear URI if capture failed
            btnUploadImage.isEnabled = false
        }
    }

    // 2. For requesting camera permission
    private val requestCameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { isGranted: Boolean ->
            if (isGranted) {
                // Permission was granted, launch the camera now
                launchCamera()
            } else {
                // Permission was denied
                Toast.makeText(this, "Camera permission is required to take photos.", Toast.LENGTH_LONG).show()
                tvResult.text = "Camera permission needed to capture plate image."
            }
        }

    // --- Retrofit Client Setup (Lazy initialization) ---
    private val apiService: ApiService by lazy {
        val logging = HttpLoggingInterceptor().apply {
            level = HttpLoggingInterceptor.Level.BODY
        }
        val client = OkHttpClient.Builder()
            .addInterceptor(logging)
            .connectTimeout(60, TimeUnit.SECONDS) // Connection timeout
            .readTimeout(60, TimeUnit.SECONDS)    // Read timeout (waiting for response)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()



        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .client(client)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(ApiService::class.java)
    }

    // --- Activity Lifecycle Methods ---
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main) // This links to your XML layout

        // --- Find all views from the layout ---
        imageView = findViewById(R.id.imageView)
        btnCaptureImage = findViewById(R.id.btnCaptureImage)
        btnUploadImage = findViewById(R.id.btnUploadImage)
        tvResult = findViewById(R.id.tvResult)

        // --- Set Click Listeners ---
        btnCaptureImage.setOnClickListener {
            checkCameraPermissionAndLaunchCamera()
        }

        btnUploadImage.setOnClickListener {
            // --- NEW FIX (The "alag" way) ---
            // This is a more standard, robust way to handle the nullable URI
            // It will 100% fix the "Smart cast" error
            currentPhotoUri?.let { uri ->
                // 'uri' is a non-null, stable value inside this block
                uploadImage(uri)
            } ?: run {
                // This 'run' block executes if currentPhotoUri is null
                Toast.makeText(this, "Please capture an image first!", Toast.LENGTH_SHORT).show()
            }
        }
    }

    // --- Core Logic Functions ---

    private fun checkCameraPermissionAndLaunchCamera() {
        when {
            ContextCompat.checkSelfPermission(
                this,
                Manifest.permission.CAMERA
            ) == PackageManager.PERMISSION_GRANTED -> {
                launchCamera()
            }
            else -> {
                requestCameraPermissionLauncher.launch(Manifest.permission.CAMERA)
            }
        }
    }

    private fun launchCamera() {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.US).format(Date())
        val imageFileName = "JPEG_${timeStamp}.jpg"

        val values = ContentValues().apply {
            put(MediaStore.MediaColumns.DISPLAY_NAME, imageFileName)
            put(MediaStore.MediaColumns.MIME_TYPE, "image/jpeg")
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                put(MediaStore.MediaColumns.RELATIVE_PATH, "Pictures/PFA_1_Plates")
            }
        }

        val contentUri = MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        currentPhotoUri = contentResolver.insert(contentUri, values)

        if (currentPhotoUri == null) {
            Toast.makeText(this, "Failed to create image file.", Toast.LENGTH_SHORT).show()
            return
        }
        takePictureLauncher.launch(currentPhotoUri!!)
    }

    private fun uploadImage(uri: Uri) {
        tvResult.text = "Verifying plate... Please wait."
        btnUploadImage.isEnabled = false
        btnCaptureImage.isEnabled = false

        val filePart = try {
            val inputStream = contentResolver.openInputStream(uri)
                ?: throw Exception("Failed to open input stream for URI: $uri")
            val tempFile = File(cacheDir, "upload_image.jpg")
            tempFile.deleteOnExit()
            FileOutputStream(tempFile).use { outputStream ->
                inputStream.copyTo(outputStream)
            }
            inputStream.close()

            // --- FIX 2 (toRequestBody -> asRequestBody) ---
            // Use 'asRequestBody' for files, not 'readBytes().toRequestBody'
            val requestFile = tempFile.asRequestBody("image/jpeg".toMediaTypeOrNull())

            MultipartBody.Part.createFormData("file", tempFile.name, requestFile)
        } catch (e: Exception) {
            Log.e("Upload", "File preparation failed", e)
            tvResult.text = "Error: Failed to prepare image for upload."
            btnUploadImage.isEnabled = true
            btnCaptureImage.isEnabled = true
            return
        }

        // --- Make the API call ---
        Log.d("Upload", "Sending image to API at $BASE_URL")
        apiService.verifyPlate(filePart).enqueue(object : Callback<VerifyResponse> {

            override fun onResponse(call: Call<VerifyResponse>, response: Response<VerifyResponse>) {
                btnUploadImage.isEnabled = true
                btnCaptureImage.isEnabled = true

                if (response.isSuccessful) {
                    val verifyResponse = response.body()
                    if (verifyResponse != null) {
                        // --- FIX 3: Changed \_n to \n ---
                        // This is the correct newline character. The build error
                        // was because the previous code had an invalid '\_'
                        val resultText = "Status: ${verifyResponse.status ?: "N/A"}\n" +
                                "Plate: ${verifyResponse.plateNumber ?: "N/A"}\n" +
                                "Owner: ${verifyResponse.details?.owner ?: "N/A"}\n" +
                                "Vehicle: ${verifyResponse.details?.vehicle ?: "N/A"}"

                        tvResult.text = resultText
                        Toast.makeText(this@MainActivity, "Verification: ${verifyResponse.status}", Toast.LENGTH_LONG).show()
                        Log.d("API_RESPONSE", "Success: $verifyResponse")
                    } else {
                        tvResult.text = "Error: Empty response body from API."
                        Log.e("API_RESPONSE", "Empty body from successful response.")
                    }
                } else {
                    val errorBody = response.errorBody()?.string()
                    tvResult.text = "Error: ${response.code()} (${response.message()})\nDetails: ${errorBody ?: "No details"}"
                    Log.e("API_RESPONSE", "API Error: ${response.code()}, Message: ${response.message()}, Body: $errorBody")
                    Toast.makeText(this@MainActivity, "API Error: ${response.code()}", Toast.LENGTH_LONG).show()
                }
            }

            override fun onFailure(call: Call<VerifyResponse>, t: Throwable) {
                btnUploadImage.isEnabled = true
                btnCaptureImage.isEnabled = true
                tvResult.text = "Network Failure: ${t.message}"
                Log.e("API_RESPONSE", "Network Failure", t)
                Toast.makeText(this@MainActivity, "Network Error: Check URL or internet.", Toast.LENGTH_LONG).show()
            }
        })
    }
}

